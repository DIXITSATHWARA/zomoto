<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Products;
use App\ProductRating;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$products = Products::where("status","active")->limit(8)->get();
        $products = DB::table('products as p')
        ->select('p.id','p.title','p.description','p.coverImage','p.price','p.discount','pr.productId',DB::raw('round(AVG(pr.rating),1) as rating'),DB::raw('COUNT(pr.id) as totalRating'))
        ->leftJoin('product_rating as pr', 'p.id', '=', 'pr.productId')
        //->where('p.status',"active")
        ->groupBy('pr.productId')
        ->limit(8)
        ->get();
        
        return view('index', compact("products")); 
    }

    public function ajaxCall(Request $request)
    {
        
        $params = $request->all();
        
        $page = !empty($request->input('page')) ? ($request->input('page') * 1) : 1;
        $products = DB::table('products as p')
        ->select('p.id','p.title','p.description','p.coverImage','p.price','p.discount','pr.productId',DB::raw('round(AVG(pr.rating),1) as rating'),DB::raw('COUNT(pr.id) as totalRating'))
        ->leftJoin('product_rating as pr', 'p.id', '=', 'pr.productId')
        ->groupBy('pr.productId')
        ->skip(($page-1)*8)
        ->limit(8)
        ->get();
        //dd($products->toArray());
        return json_encode($products->toArray());
    }

    public function filterData(Request $request)
    {
        
        $params = $request->all();
        $whereCond = "p.status = 'active'";
        if(!empty($params['search'])){
            $whereCond .= (!empty($whereCond)) ? " AND " : "";
            $whereCond .= "p.title LIKE '%" . $params['search'] . "%'";
        }
        if(!empty($params['type'])){
            $whereCond .= (!empty($whereCond)) ? " AND " : "";
            $whereCond .= "p.type = '" . $params['type'] . "'";
        }

        $whereCond = !empty($whereCond) ? "(" . $whereCond . ")" : "";
        //dd($whereCond);
        $page = !empty($request->input('page')) ? ($request->input('page') * 1) : 1;
        $products = DB::table('products as p')
        ->select('p.id','p.title','p.description','p.coverImage','p.price','p.discount','pr.productId',DB::raw('round(AVG(pr.rating),0) as rating'),DB::raw('COUNT(pr.id) as totalRating'))
        ->leftJoin('product_rating as pr', 'p.id', '=', 'pr.productId')
        ->whereRaw($whereCond)
        ->groupBy('pr.productId')
        ->limit($page*8)
        ->get();
        
        return view('index', compact("products","params")); 
    }
}
