<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <title>Zomoto</title>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    <link href="{{ url('public\css\style.css') }}" rel="stylesheet" />

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
</head>

<body>
    <div class="container">
        <h2 class="h2">Zomoto</h2>
        <div>
            <form id="filter" name="filter" method="POST" action="{{ url('filterData') }}">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <input name="search" class="form-control" id="search" type="text" placeholder="Search.." value="<?php echo !empty($params['search']) ? $params['search'] : "" ?>">
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <select name="type" id="type" class="form-control form-select" aria-label="Default select example">
                            <option value="">-Food Type-</option>
                            <option value="VEG" <?php echo (!empty($params['type']) && $params['type'] == "VEG") ? "selected" : "" ?>>VEG</option>
                            <option value="NONVEG" <?php echo (!empty($params['type']) && $params['type'] == "NONVEG") ? "selected" : "" ?>>NONVEG</option>
                        </select>
                    </div>
                    <input type="hidden" name="page" id="filterpage" value="1" />
                    <div class="col-md-2 col-sm-6">
                        <input class="form-control btn btn-primary" id="search" type="submit" value="Filter">
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <a href="{{ url('/') }}" class="form-control btn btn-danger" id="search">Clear</a>
                    </div>
                </div>
            </form>
        </div><br>
        <div class="row" id="div-to-update" style="height: auto; max-height:600px; overflow-y:scroll;">
            @if(!empty($products))
            @foreach($products as $key => $val)
            <div class="col-md-3 col-sm-6">
                <div class="product-grid">
                    <div class="product-image">
                        <a href="#">
                            <img class="pic-1" src="{{ url('/public/products',$val->coverImage) }}" heigt="100" width="100">
                            <img class="pic-2" src="{{ url('/public/products',$val->coverImage) }}" heigt="100" width="100">
                        </a>
                        <span class="product-new-label">Sale</span>
                        @if(!empty($val->discount) && $val->discount > 0)
                        <span class="product-discount-label">{{$val->discount}}%</span>
                        @endif
                    </div>
                    <ul class="rating">
                        @php
                        $rating = round($val->rating);
                        for($i=1;$i<=$rating;$i++){ echo '<li class="fa fa-star"></li>' ; } for($i=1;$i<=(5-$rating);$i++){ echo '<li class="fa fa-star disable"></li>' ; } @endphp </ul>
                            <span align="center">({{ $val->totalRating }} Reviews)</span>
                            <div class="product-content">
                                <h3 class="title"><a href="#">{{ $val->title }}</a></h3>
                                <div class="price">₹{{$val->price}}
                                </div>
                                <a class="add-to-cart" href="">+ Add To Cart</a>
                            </div>
                </div>
            </div>
            @endforeach
            @endif
            <input type="hidden" name="page" id="page" value="1" />
        </div>
    </div>
    <script>
        $(document).ready(function() {
            var page = 1;
            $('#div-to-update').on('scroll', function() {
                if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
                    nextPage();
                }
            })

            function nextPage() {

                page = (Number(page) + 1)
                
                var pageurl = "{{ Request::segment(1)}}";
                if (pageurl == "filterData") {
                    $("#filterpage").val(page);
                    $('#filter').submit();
                }

                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                var url = "{{ url('ajaxCall') }}";
                var data = {
                    _token: CSRF_TOKEN,
                    page: page
                }


                $.ajax({
                    url: url,
                    type: 'POST',
                    data: data,
                    dataType: 'JSON',
                    success: function(data) {
                        if (data && data.length > 0) {
                            for (var i = 0; i < data.length; i++) {
                                var discount = ""
                                if (data[i].discount && data[i].discount > 0) {
                                    discount = '<span class="product-discount-label">' + data[i].discount + '%</span>'
                                }
                                var html = '<div class="col-md-3 col-sm-6"><div class="product-grid"><div class="product-image"><a href="#"><img class="pic-1" src="{{ url("/public/products")}}/' + data[i].coverImage + '" heigt="100" width="100"><img class="pic-2" src="{{ url("/public/products")}}/' + data[i].coverImage + '" heigt="100" width="100"></a><span class="product-new-label">Sale</span>' + discount + '</div><ul class="rating"><li class="fa fa-star"></li><li class="fa fa-star"></li><li class="fa fa-star"></li><li class="fa fa-star"></li><li class="fa fa-star disable"></li></ul><div class="product-content"><h3 class="title"><a href="#">' + data[i].title + '</a></h3><div class="price">₹' + data[i].price + '</div><a class="add-to-cart" href="">+ Add To Cart</a></div></div></div>';

                                $("#div-to-update").append(html);
                            }
                        }
                    }
                });
            }
        });

    </script>
</body>

</html>