<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //DB::table('products')->truncate();

        $products = array(
            array(
                'title' => "Chole Bhature",
                'description' => "Chole bhature is a food dish popular in the Northern areas of the Indian subcontinent. It is a combination of chana masala and bhatura/puri, a fried bread made from maida. Although it is known as a typical Punjabi dish, there are varied claims around the origin of dish.",
                'price' => 200,
                'discount' => 0,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "bhatura-pakwangali-520_041320010508.webp",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Dahi Bhalla",
                'description' => "Dahi vada is a type of chaat originating from the Indian subcontinent and popular throughout South Asia. It is prepared by soaking vadas in thick dahi.",
                'price' => 100,
                'discount' => 0,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "dahi-vada-recipe.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Raj Kachori",
                'description' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
                'price' => 150,
                'discount' => 10,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "raj-kachori-chaat-recipe-1.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Butter Pav Bhaji",
                'description' => "Pav bhaji is a fast food dish from India consisting of a thick vegetable curry served with a soft bread roll. Its origins are in the state of Maharashtra.",
                'price' => 170,
                'discount' => 20,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "pav-bhaji.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Matar Kulcha",
                'description' => "Kulcha is a type of mildly leavened flatbread that originated in the Indian subcontinent.",
                'price' => 190,
                'discount' => 5,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "streetstyle-matar-kulcha-recipe-main-photo.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Aloo Tikki",
                'description' => "Aloo tikki, also known as Aloo ki tikkia or Aloo ki tikki, is a snack originating from the Indian subcontinent; in Indian, Pakistani, and Bangladeshi preparation, it is made of boiled potatoes, peas, and various curry spices. Aloo means potato, and tikki means a small cutlet or croquette in Hindi-Urdu and Marathi.",
                'price' => 180,
                'discount' => 0,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "Aloo-Tikki-2-3.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Rasmalai",
                'description' => "Ras malai or rossomalai or Rasamalei is a dessert originating from the eastern regions of the Indian subcontinent. The dessert is called rossomalai in Bengali language, ras malai in Hindi language and Rasa Malei in Odia language.",
                'price' => 250,
                'discount' => 0,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "traditional_rasmalai_recipe.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Lazeez Bhuna Murgh",
                'description' => "Lazeez Bhuna Murgh [Chicken Biryani Boneless - Serves 1]",
                'price' => 260,
                'discount' => 0,
                'type' => "NONVEG",
                'status' => "active",
                'coverImage' => "index.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Murgh Afghani Tikka",
                'description' => "Murgh Afghani Tikka (Creamy Chicken Tikka Biryani - Serves 4-5)",
                'price' => 500,
                'discount' => 20,
                'type' => "NONVEG",
                'status' => "active",
                'coverImage' => "Murgh Afghani Tikka.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Chicken Afghani",
                'description' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
                'price' => 360,
                'discount' => 25,
                'type' => "NONVEG",
                'status' => "active",
                'coverImage' => "afghani-chicken.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Chole Bhature 2",
                'description' => "Chole bhature is a food dish popular in the Northern areas of the Indian subcontinent. It is a combination of chana masala and bhatura/puri, a fried bread made from maida. Although it is known as a typical Punjabi dish, there are varied claims around the origin of dish.",
                'price' => 200,
                'discount' => 0,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "bhatura-pakwangali-520_041320010508.webp",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Dahi Bhalla 2",
                'description' => "Dahi vada is a type of chaat originating from the Indian subcontinent and popular throughout South Asia. It is prepared by soaking vadas in thick dahi.",
                'price' => 100,
                'discount' => 0,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "dahi-vada-recipe.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Raj Kachori 2",
                'description' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
                'price' => 150,
                'discount' => 10,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "raj-kachori-chaat-recipe-1.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Butter Pav Bhaji 2",
                'description' => "Pav bhaji is a fast food dish from India consisting of a thick vegetable curry served with a soft bread roll. Its origins are in the state of Maharashtra.",
                'price' => 170,
                'discount' => 20,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "pav-bhaji.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Matar Kulcha 2",
                'description' => "Kulcha is a type of mildly leavened flatbread that originated in the Indian subcontinent.",
                'price' => 190,
                'discount' => 5,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "streetstyle-matar-kulcha-recipe-main-photo.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Aloo Tikki 2",
                'description' => "Aloo tikki, also known as Aloo ki tikkia or Aloo ki tikki, is a snack originating from the Indian subcontinent; in Indian, Pakistani, and Bangladeshi preparation, it is made of boiled potatoes, peas, and various curry spices. Aloo means potato, and tikki means a small cutlet or croquette in Hindi-Urdu and Marathi.",
                'price' => 180,
                'discount' => 0,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "Aloo-Tikki-2-3.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Rasmalai 2",
                'description' => "Ras malai or rossomalai or Rasamalei is a dessert originating from the eastern regions of the Indian subcontinent. The dessert is called rossomalai in Bengali language, ras malai in Hindi language and Rasa Malei in Odia language.",
                'price' => 250,
                'discount' => 0,
                'type' => "VEG",
                'status' => "active",
                'coverImage' => "traditional_rasmalai_recipe.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Lazeez Bhuna Murgh 2",
                'description' => "Lazeez Bhuna Murgh [Chicken Biryani Boneless - Serves 1]",
                'price' => 260,
                'discount' => 0,
                'type' => "NONVEG",
                'status' => "active",
                'coverImage' => "index.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Murgh Afghani Tikka 2",
                'description' => "Murgh Afghani Tikka (Creamy Chicken Tikka Biryani - Serves 4-5)",
                'price' => 500,
                'discount' => 20,
                'type' => "NONVEG",
                'status' => "active",
                'coverImage' => "Murgh Afghani Tikka.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ),
            array(
                'title' => "Chicken Afghani 2",
                'description' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
                'price' => 360,
                'discount' => 25,
                'type' => "NONVEG",
                'status' => "active",
                'coverImage' => "afghani-chicken.jpg",
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            )
        );

        DB::table('products')->insert($products);

    }
}
