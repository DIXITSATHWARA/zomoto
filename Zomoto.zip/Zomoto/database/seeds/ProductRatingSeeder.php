<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ProductRatingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('product_rating')->truncate();
        $product_rating = array();

        for ($i = 0; $i < 2000; $i++) {
            $product_rating[] = [
                'productId' => rand(1,20),
                'rating' => rand(1,5),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ];
        }

        DB::table('product_rating')->insert($product_rating);
    }
}
